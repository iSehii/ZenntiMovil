// GuestScreen.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationProp } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Login from '../auth/login';
import Mapa from '../invitado/Mapa';
import Test from '../invitado/Test';
import Menues from './menu';
import InicioGuest from '../invitado/Inicio';
interface InvitadoProps {
    navigation: NavigationProp<any>;
}
const Invitado: React.FC<InvitadoProps> = ({ navigation }) => {
    const Tab = createBottomTabNavigator();

    const Inicio = () => (
        <View style={styles.container}>
            <InicioGuest/>
        </View>
    );

    const Ubicaciones = () => (
        <View style={styles.container}>
            <Mapa/>
        </View>
    );

    const Menu = () => (
        <View style={styles.container}>
            <Menues navigation={navigation}/>
        </View>
    );

    const Estadisticas = () => (
        <View style={styles.container}>
            <Test/>
        </View>
    );

    return (
        <View style={styles.container}>

            <View style={[styles.box, styles.box3]}>
                <Tab.Navigator
                    screenOptions={{
                        tabBarActiveTintColor: 'red',
                        tabBarInactiveTintColor: 'gray',
                        tabBarStyle: [
                            {
                                paddingTop: 10,
                                display: 'flex',
                                borderTopWidth: 2,
                                borderTopColor: '#ccc'
                            },
                            null,
                        ],
                    }}
                >
                    <Tab.Screen
                        name="Inicio"
                        component={Inicio}
                        options={{
                            headerShown: false,
                            tabBarIcon: ({ color, size }) => (
                                <Ionicons name="home" color={color} size={size} />
                            ),
                        }}
                    />
                    <Tab.Screen
                        name="Ubicaciones"
                        component={Ubicaciones}
                        options={{
                            headerShown: false,
                            tabBarIcon: ({ color, size }) => (
                                <Ionicons name="map" color={color} size={size} />
                            ),
                        }}
                    />
                    <Tab.Screen
                        name="Estadìsticas"
                        component={Estadisticas}
                        options={{
                            headerShown: false,
                            tabBarIcon: ({ color, size }) => (
                                <Ionicons name="analytics" color={color} size={size} />
                                ),
                            }}
                    />
                    <Tab.Screen
                        name="Menú"
                        component={Menu}
                        options={{
                            headerShown: false,
                            tabBarIcon: ({ color, size }) => (
                                <Ionicons name="menu" color={color} size={size} />
                                ),
                            }}
                    />
                </Tab.Navigator>
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    container: {
        paddingTop: 25,
        flex: 1,
        flexDirection: 'column'
    },
    box: {
    },
    box1: {
        flex: 1,
            backgroundColor: '#2196F3'
    },
    //content 
    box2: {
        flex: 10,
            backgroundColor: '#8BC34A'
    },
    //footer 
    box3: {
        paddingTop: 0,
        flex: 1,
        backgroundColor: '#e3aa1a'
    }
});
export default Invitado;
