import { View, Text, StyleSheet } from 'react-native';
import React, { useState } from 'react';
import Svg, { Rect } from 'react-native-svg';
import Icono from 'react-native-vector-icons/MaterialCommunityIcons';

const BatteryIcon = () => {
    const percentage = 100;
    const batteryWidth = 30;
    const batteryHeight = 15;
    const borderWidth = 2;

    const batteryLevel = (batteryWidth - 2 * borderWidth) * (percentage / 100);
    const [color, setColor] = useState("green");
//     
//        if (percentage>=0 && percentage<=20) {
  //          setColor('orange');
    //    } else {
      //      setColor("green");
       // }

    return (
        <View style={styles.contenedor}>
            <View>
                <Text style={styles.Titulo}>Bancos disponibles</Text>
            </View>
            <View style={styles.banco}>
                <View>
                    <Text style={styles.bancoTitulo}>Banco 1</Text>
                </View>
                <View style={styles.bancoPorcentaje}>
                    <Svg width={batteryWidth} height={batteryHeight} viewBox={`0 0 ${batteryWidth} ${batteryHeight}`}>
                        <Rect
                            x={0}
                            y={0}
                            width={batteryWidth}
                            height={batteryHeight}
                            stroke="black"
                            strokeWidth={borderWidth}
                            fill="none" /><Rect
                            x={borderWidth}
                            y={borderWidth}
                            width={batteryLevel}
                            height={batteryHeight - 2 * borderWidth}
                            fill={color} />
                    </Svg>
                    <Text>{`${percentage}%`}</Text>
                </View>
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    contenedor: {
        flex: 1,
    },
    Titulo: {
        fontSize: 30,
    },
    banco: {
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
        flexDirection: 'row',
        borderWidth: 1,
    },
    bancoTitulo: {
        alignContent: 'center',
        alignItems: 'center',
        fontSize: 25,
        fontWeight: 'bold',
    },
    bancoPorcentaje: {
        alignContent: 'center',
        justifyContent: 'center',
        right: 0,
        alignItems: 'center',

    }
});
export default BatteryIcon;
