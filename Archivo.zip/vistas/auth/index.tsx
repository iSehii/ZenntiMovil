// Inicio.js
import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, StatusBar, Image, ScrollView } from 'react-native';
import { NavigationProp } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface InicioProps {
    navigation: NavigationProp<any>; // Puedes ajustar el tipo según tus necesidades
}

const Inicio: React.FC<InicioProps> = ({ navigation }) => {
    const [logueado, setLogueado] = useState(false);

    useEffect(() => {
      const checkLogueado = async () => {
        try {
          var sesion = await AsyncStorage.getItem('logueado');
          console.log(sesion);
          setLogueado(sesion === 'true'); // Assuming 'logueado' is stored as a string
        } catch (error) {
          console.error(error);
        }
      };
  
      checkLogueado();
    }, []);
    const invited = async () => {
        await AsyncStorage.setItem('invitado', '1');
        navigation.reset({
            index: 0,
            routes: [{ name: 'Invitado' }]
        });
    };
    return (
        <View style={{marginTop: 50, flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            <StatusBar />
            <Text style={{textAlign: 'center', fontSize: 60, color: 'black', fontWeight: 'bold', margin: 0}}>¡Hola!</Text>
                <View style={{alignContent: 'center', justifyContent: 'center', alignItems: 'center', width: '100%', padding: 10}}>
                    <Image style={{width: 500, height: 400}} source={(require('../../public/imagenes/Inicio.png'))}/>
                </View>
            <View>
                <View>
                    <Text style={{ textAlign: 'center', justifyContent: 'center', marginTop: 0, fontSize: 18 }}>
                        Para continuar, por favor{'\n'}Prueba a:
                    </Text>
                </View>
                <View style={styles.Botones}>
                    <Button 
                        color={'white'}
                        title="Iniciar sesión"
                        onPress={() => navigation.navigate('Iniciar sesión')}
                        />
                </View>
                <View>
                    <Text style={{textAlign: 'center', color: 'gray', justifyContent: 'center', marginTop: -12, fontSize: 22}}>__________________________</Text>
                </View>
                <View style={styles.Botones}>
                    <Button 
                        color={'white'}
                        title="Registrarse"
                        onPress={() => navigation.navigate('Registro')}
                        />
                </View>
                <View>
                    <Text style={{ textAlign: 'center', justifyContent: 'center', marginTop: 5, fontSize: 22 }}>ó</Text>
                </View>
                <View style={styles.Invitado}>
                    <Button 
                        color={'black'}
                        title="Continuar como invitado"
                        onPress={invited}
                        />
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    Botones: {
        borderWidth: 0,
        marginTop: 7,
        backgroundColor: 'black',
        borderRadius: 12,
        color: 'white',
        padding: 5,
        width: 300,
        borderColor: 'transparent',
    },
    Invitado: {
        margin: 4,
        borderWidth: 1,
        borderColor: 'black',
        borderRadius: 12,
        color: 'black',
    }
});

export default Inicio;
