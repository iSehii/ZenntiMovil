import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import Svg, { Rect } from 'react-native-svg';
import Icono from 'react-native-vector-icons/MaterialCommunityIcons';
import IconoMaterial from 'react-native-vector-icons/Ionicons';

const BatteryIcon = () => {
    const percentage = 100;
    const batteryWidth = 40;
    const batteryHeight = 20;
    const borderWidth = 2;

    const batteryLevel = (batteryWidth - 2 * borderWidth) * (percentage / 100);
    const [color, setColor] = useState("#3bc43b");
//     
//        if (percentage>=0 && percentage<=20) {
  //          setColor('orange');
    //    } else {
      //      setColor("green");
       // }

    return (
        <View style={styles.contenedor}>
            <View style={{margin: 10}}>
                <Text style={styles.Titulo}>Bancos disponibles</Text>
            </View>
            <View style={styles.banco}>
                <View>
                    <Text style={styles.bancoTitulo}>Proyecto</Text>
                    <View style={{ flexDirection: 'row', alignContent: 'center', alignItems: 'center', justifyContent: 'center' }}>
                        <View style={{ alignContent: 'center', alignItems: 'center', justifyContent: 'center', flexDirection: 'row' }}>
                            <Svg width={batteryWidth} height={batteryHeight} viewBox={`0 0 ${batteryWidth} ${batteryHeight}`}>
                                <Rect
                                    x={0}
                                    y={0}
                                    width={batteryWidth}
                                    height={batteryHeight}
                                    stroke="black"
                                    strokeWidth={borderWidth}
                                    fill="none" />
                                <Text style={{ textAlign: 'center', marginTop: 0, fontWeight: 'bold' }}>{`${percentage}`}</Text>
                                <Rect
                                    x={borderWidth}
                                    y={borderWidth}
                                    width={batteryLevel}
                                    height={batteryHeight - 2 * borderWidth}
                                    fill={color} />
                            </Svg>
                        </View>
                    </View>
                </View>
                <View style={styles.bancoPorcentaje}>
                    <View style={{ flexDirection: 'row', alignContent: 'center', alignItems: 'center', justifyContent: 'center' }}>
                        <TouchableOpacity>
                            <Icono name="google-maps" color={"darkred"} size={40} />
                        </TouchableOpacity>
                        <TouchableOpacity>
                            <IconoMaterial name="analytics" color={"darkred"} size={40} />
                        </TouchableOpacity>
                    </View>

                </View>
            </View>
        </View>
    );
};
const styles = StyleSheet.create({
    contenedor: {
        flex: 1,
    },
    Titulo: {
        fontSize: 30,
        fontWeight: 'bold',
    },
    banco: {
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
        flexDirection: 'row',
        borderWidth: 1,
    },
    bancoTitulo: {
        alignContent: 'center',
        alignItems: 'center',
        fontSize: 25,
        fontWeight: 'bold',
    },
    bancoPorcentaje: {
        alignContent: 'center',
        justifyContent: 'center',
        right: 0,
        flexDirection: 'row',
        alignItems: 'center',

    }
});
export default BatteryIcon;
