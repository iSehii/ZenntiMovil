import React, { useState } from 'react';
import { View, TextInput, Button, Text } from 'react-native';
import MapView, { Marker } from 'react-native-maps';

const App = () => {
    const [latLngInput, setLatLngInput] = useState('');
    const [markerPosition, setMarkerPosition] = useState(null);
    const [formattedAddress, setFormattedAddress] = useState('');

    const handleGeocode = async () => {
        const latLngArray = latLngInput.split(',');
        const latitude = parseFloat(latLngArray[0]);
        const longitude = parseFloat(latLngArray[1]);

        try {
            const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyD3Wbd0AVBHJ6cqKGFQrtMZvtPlg6qzqLU`);
            const data = await response.json();

            if (data.results && data.results.length > 0) {
                const address = data.results[0].formatted_address;
                setFormattedAddress(address);
                setMarkerPosition({ latitude, longitude });
            } else {
                window.alert('No se encontró ninguna dirección.');
            }
        } catch (error) {
            console.error('Error en la geocodificación inversa:', error);
            window.alert(`Error en la geocodificación inversa: ${error}`);
        }
    };

    return (
        <View style={{ flex: 1 }}>
            <MapView
                style={{ flex: 1 }}
                initialRegion={{
                    latitude: 19.3399521,
                    longitude: -99.4756845,
                    latitudeDelta: 0.0922,
                    longitudeDelta: 0.0421,
                }}
            >
                {markerPosition && <Marker coordinate={markerPosition} title="Ubicación" />}
            </MapView>
            <View style={{ padding: 10 }}>
                <TextInput
                    placeholder="Ingrese latitud y longitud (por ejemplo, 37.78825, -122.4324)"
                    value={latLngInput}
                    onChangeText={(text) => setLatLngInput(text)}
                    style={{ marginBottom: 10, borderBottomWidth: 1, paddingBottom: 5 }}
                />
                <Button title="Geocodificar" onPress={handleGeocode} />
                {formattedAddress !== '' && (
                    <Text style={{ marginTop: 10, fontWeight: 'bold' }}>{`Dirección: ${formattedAddress}`}</Text>
                )}
            </View>
        </View>
    );
};

export default App;
