// App.js
import React, { useState, useEffect } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Inicio from './vistas/auth/index';
import Login from './vistas/auth/login/index';
import Registro from './vistas/auth/registro/index';
import Invitado from './vistas/invitado/index';
import InicioLogueado from './vistas/logueado/index';
import MiCuenta from './vistas/logueado/MiCuenta';
import Chequeo from './vistas/chequeo';
const Stack = createStackNavigator();

const App = () => {
  return (
    <View style={{ flex: 1, paddingTop: StatusBar.currentHeight || 0 }}>
      <StatusBar />
      <NavigationContainer>
        <Stack.Navigator initialRouteName='Chequeo'>
          <Stack.Screen name="Inicio" component={Inicio} options={{ headerShown: false, headerBackTitle: ' Volver' }} />
          <Stack.Screen name="Iniciar sesión" component={Login} options={{ headerShown: false, headerBackTitle: 'Atrás' }} />
          <Stack.Screen name="Registro" component={Registro} options={{ headerShown: false, headerBackTitle: 'Atrás' }} />
          <Stack.Screen name="Invitado" component={Invitado} options={{ headerShown: false }} />
          <Stack.Screen name="InicioLogueado" component={InicioLogueado} options={{ headerShown: false }} />
          <Stack.Screen name="Chequeo" component={Chequeo} options={{ headerShown: false }} />
          <Stack.Screen name="MiCuenta" component={MiCuenta} options={{ headerShown: false }} />
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
};

export default App;
